<?php
  include_once ('db_conn.php');

  /* Determinamos el id del registro a borrar. */
  $id = $_GET["id"];

  /* Determinamos si el usuario a eliminar tiene un avatar, 
  para borrarlo, para que no queden avatares huérfamnos. */
  $consulta = "SELECT avatar FROM socios ";
  $consulta .= "WHERE id = '".$id."';";
  $hacerConsulta = $conexion->query($consulta);
  $avatarAlmacenado = $hacerConsulta->fetch(PDO::FETCH_ASSOC)["avatar"];
  $hacerConsulta->closeCursor();
  if (strpos($avatarAlmacenado, "sin_avatar") === false) {
    @unlink($avatarAlmacenado);
  }
  
  /* Eliminamos el registro */
  $consulta = "DELETE FROM socios ";
  $consulta .= "WHERE id = '".$id."';";
  $conexion->query($consulta);
?>
