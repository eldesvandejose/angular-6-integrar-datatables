<?php
    include ('../db_conn.php');
    require_once './vendor/autoload.php';

    use Firebase\JWT\JWT;

    $privateKey = 'XAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9';

    $tokenJWT = $_GET["token"];

    if ($tokenJWT == null) {
        $datosDeRetorno = [
            "correcto" => "N"
        ];
    } else { // Si hay un token
        try {
            $dataObject = JWT::decode($tokenJWT, $privateKey, array('HS256', 'HS384', 'HS512', 'RS256', 'RS384', 'RS512'));
            $dataArray = json_decode(json_encode($dataObject), true);
            $adminData = $dataArray["userData"];
            /**
             * Leemos la pass de la BD, si existe el admin
             */
            $consulta = "SELECT ";
            $consulta .= "password, ";
            $consulta .= "nombre, ";
            $consulta .= "role ";
            $consulta .= "FROM admins ";
            $consulta .= "WHERE ";
            $consulta .= "login = '".$adminData["login"]."';";
            $hacerConsulta = $conexion->query($consulta);
            $datosDeAdmin = $hacerConsulta->fetch(PDO::FETCH_ASSOC);
            $hacerConsulta->closeCursor();
            if (password_verify($adminData["password"], $datosDeAdmin["password"]) === false) {
                $datosDeRetorno = [
                    "correcto"=>"N"
                ];
            } else {
                $datosDeRetorno = [
                    "correcto"=>"S",
                    "nombreAdmin"=>$datosDeAdmin["nombre"],
                    "rolAdmin"=>$datosDeAdmin["role"]
                ];
            }
        } catch (Exception $e) {
            $datosDeRetorno = [
                "correcto" => "N"
            ];
        }
    }

    $datosDeRetorno = json_encode($datosDeRetorno);
    echo $datosDeRetorno;
?>

