/**
 * Este componente es una vista de acceso prohibido.
 * Se usa cuando un visitante intenta acceder a una vista a la que
 * solo tienen acceso los administradores. También salta si
 * un administrador de bajo nivel intenta acceder al formulario
 * de nuevo miembro o de edición.
 */
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'a6b-forbidden',
  templateUrl: './forbidden.component.html',
  styleUrls: ['./forbidden.component.css']
})
export class ForbiddenComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
}
