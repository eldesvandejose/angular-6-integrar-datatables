import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
/* Importamos la clase Member que necesitaremos para
gestionar los objetos de los usuarios. */
import { Member } from '../classes/member';
import { DataTablesResponse } from '../classes/data-tables-response';
import { CheckAdminService } from '../../services/check-admin.service';
import { HttpConnectService } from '../services/http-connect.service';

declare var $: any;
declare var jQuery: any;

@Component({
  selector: 'a6b-members-list',
  templateUrl: './members-list.component.html',
  styleUrls: ['./members-list.component.css']
})

export class MembersListComponent implements OnInit {

  dtOptions: DataTables.Settings = {};
  Members: Member[];
  NumberOfMembers = 0;

  nombreAdmin: string;
  rolAdmin: string;

  /* En el constructor creamos el objeto connectService,
  de la clase HttpConnectService, que contiene el servicio mencionado,
  y estará disponible en toda la clase de este componente.
  El objeto es private, porque no se usará fuera de este componente. */
  constructor(
    private router: Router,
    private checkAdmin: CheckAdminService,
    private connectService: HttpConnectService
  ) {}

  /* Al inicio del componente se llevan a cabo varias operaciones:
    - Establecemos el título para la pestaña del navegador.
    - Determinamos el nivel de admin, si lo hay.
    - Definimos las opciones del DT. */
  ngOnInit() {
    $(document).prop('title', 'Lista de miembros');
    this.checkAdmin.checkToken();
    if (
      localStorage.getItem('rolAdmin') !== 'ROLE_FULL' &&
      localStorage.getItem('rolAdmin') !== 'ROLE_ADMIN'
    ) {
      this.router.navigateByUrl('forbidden');
    }
    this.nombreAdmin = localStorage.getItem('nombreAdmin');
    this.rolAdmin = localStorage.getItem('rolAdmin');

    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 10,
      serverSide: true,
      processing: true,
      info: true,
      language: {
        emptyTable: '',
        zeroRecords: 'No hay coincidencias',
        lengthMenu: 'Mostrar _MENU_ elementos',
        search: 'Buscar:',
        info: 'De _START_ a _END_ de _TOTAL_ elementos',
        infoEmpty: 'De 0 a 0 de 0 elementos',
        infoFiltered: '(filtrados de _MAX_ elementos totales)',
        paginate: {
          first: 'Prim.',
          last: 'Últ.',
          next: 'Sig.',
          previous: 'Ant.'
        },
      },
      ajax: (dataTablesParameters: any, callback) => {
        this.connectService.http
          .post<DataTablesResponse>(
            this.connectService.URL + 'read_records_dt.php',
            dataTablesParameters, {}
          ).subscribe(resp => {
            this.Members = resp.data;
            this.NumberOfMembers = resp.data.length;
            $('.dataTables_length>label>select, .dataTables_filter>label>input').addClass('form-control-sm');
            callback({
              recordsTotal: resp.recordsTotal,
              recordsFiltered: resp.recordsFiltered,
              data: []
            });
            if (this.NumberOfMembers > 0) {
              $('.dataTables_empty').css('display', 'none');
            }
          }
        );
      },
      columns: [{ data: 'doi' }, { data: 'nombre' }, { data: 'fecha_de_ingreso' }]
    };
  }
}
