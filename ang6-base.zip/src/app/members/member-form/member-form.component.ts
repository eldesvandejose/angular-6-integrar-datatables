import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { HttpConnectService } from '../services/http-connect.service';
import { DataPackService } from '../../services/data-pack.service';

import { Member } from '../classes/member';
import * as moment from 'moment';
import { CheckAdminService } from '../../services/check-admin.service';

declare var $: any;
declare var jQuery: any;

@Component({
  selector: 'a6b-member-form',
  templateUrl: './member-form.component.html',
  styleUrls: ['./member-form.component.css']
})
export class MemberFormComponent implements OnInit {
  public idRecibido: string; // Si edición, el id de miembro. Si nuevo, undefined
  public member: Member; // Objeto para los datos del miembro

  // Datos de miembro
  public doi: string; // Enlace con el formulario
  public nombre: string; // Enlace con el formulario
  public doiGrabar: string; // Para procesar sin espacios
  public nombreGrabar: string; // Para procesar sin espacios
  public fecha_de_ingreso: string; // Enlace con el formulario
  public genero: string; // Enlace con el formulario
  public avatarFile: any; // El fichero del avatar procedente del campo file
  public avatarName: string; // Para almacenar temporalmente el nombre del fichero del avatar
  public imageToShow: string; // El avatar en base64, si lo hay (enlaza con el src del formulario)
  public activo: string; // Enlace con el formulario
  public dataPack: FormData; // Empaquetado de todo (inc. avatar) para mandar a grabar.

  /* Flags de resultados. Determinarán que en el formulario se muestren
  mensajes con los resultados de la operación. */
  public errorEnAvatar = false;
  public errorEnDoi = false;
  public doiRepetido = false;
  public errorEnNombre = false;
  public errorEnFecha = false;
  public errorEnGenero = false;
  public errorDeProceso = false;
  public registroGrabado = false;
  public errorMessage = ''; // Para mostrar un mensaje de error desde el método de captura de errores.

  public doiIcon = 'ion-md-create';
  public nameIcon = 'ion-md-create';

  /* La siguiente variable establecerá la ruta para llegar a la lista de usuarios,
  Se usará para pasarla a la vista para configurar el botón que lleva directamente a
  la lista de miembros. */
  public rutaParaLista: string;

  /* En la firma del constructor creamos un objeto de la clase HttpConnectService,
  para poder acceder a las conexiones con API's.
  También creamos un objeto de la clase ActivatedRoute, porque si llegamos hasta aquí
  desde edición debemos poder recuperar de la ruta el id del usuario a editar. */
  constructor(
    private packService: DataPackService,
    private connectService: HttpConnectService,
    private ruta: ActivatedRoute,
    private router: Router,
    private checkAdmin: CheckAdminService
  ) {
    this.doi = '';
    this.nombre = '';
    this.avatarName = 'avatares/sin_avatar.jpg';
    this.idRecibido = this.ruta.snapshot.params['id'];
    this.imageToShow = this.connectService.URL + 'avatares/sin_avatar.jpg';
    /* Si hay un id recibido estamos en edición, por lo que
    lo primero es leer los datos del miembro que vamos a editar. */
    if (this.idRecibido !== undefined) {
      this.rutaParaLista = '../../';
      this.readCurrentData(); // Leer los datos actuales del miembro, si estamos en edición.
    } else {
      this.rutaParaLista = '../';
      this.idRecibido = '0';
      this.activo = 'S'; // Los nuevos miembros están activos por defecto.
      /* Para nuevo miembro, se muestra, por defecto, el avatar genérico,
      y se establece la fecha de alta como la del día en curso. */
      this.setCurrentDate();
    }
  }

  ngOnInit() {
    if (this.idRecibido === '0') {
      $(document).prop('title', 'Nuevo miembro');
    } else {
      $(document).prop('title', 'Editar miembro');
    }
    this.checkAdmin.checkToken();
    if (localStorage.getItem('rolAdmin') !== 'ROLE_FULL') {
      this.router.navigateByUrl('forbidden');
    }
  }

  /* Cuando se entra por edición se leen los datos actuales del socio. */
  private readCurrentData() {
    this.connectService
      .readCurrentData$(this.idRecibido)
      .subscribe(this.readSuccess.bind(this), this.catchError.bind(this));
  }

  /* Cuando se han leido los datos del socio, se alojan
  en las propiedades de la clase. */
  private readSuccess(item) {
    this.avatarName = item.avatar;
    this.doi = item.doi;
    this.nombre = item.nombre;
    this.fecha_de_ingreso = item.fecha_de_ingreso;
    this.genero = item.genero;
    this.imageToShow = this.connectService.URL + item.avatar;
    this.activo = item.activo;
    this.doiIcon = 'ion-md-checkmark';
    this.nameIcon = 'ion-md-checkmark';
    sessionStorage.setItem('LastEditedName', this.nombre);
  }

  /* Cuando se pulsa un botón de género se asigna
  su valor a la variable correspondiente. */
  public checkGender(gender) {
    this.genero = gender;
  }

  /* Cuando se pulsa el botón de activo o no activo
  (sólo disponible en edición). */
  public checkActive(active) {
    this.activo = active;
  }

  /* El siguiente método comprueba el DOI en tiempo real */
  public checkDoi() {
    this.doiGrabar = this.doi;
    this.doiGrabar = this.doiGrabar.trim().toUpperCase();
    if (this.doiGrabar === '') {
      this.doiIcon = 'ion-md-create';
    } else {
      this.checkRepeatedDoi();
    }
  }

  private checkRepeatedDoi() {
    this.connectService
      .checkRepeatedDoi$(this.idRecibido, this.doiGrabar)
      .subscribe(
        this.checkRepeatedDoiSuccess.bind(this),
        this.catchError.bind(this)
      );
  }

  private checkRepeatedDoiSuccess(result) {
    this.doiIcon = result === 'S' ? 'ion-md-close' : 'ion-md-checkmark';
    this.doiRepetido = this.doiIcon === 'ion-md-close';
  }

  /* Comprobamos en tiempo real que el nombre no esté vacío */
  public checkName() {
    this.nombreGrabar = this.nombre;
    this.nombreGrabar = this.nombreGrabar.trim();
    this.nameIcon =
      this.nombreGrabar === '' ? 'ion-md-create' : 'ion-md-checkmark';
  }

  /* Cuando se pulsa el botón de grabación, se hace una validación previa de los datos.
  Si cumplen, se graba. Si no, se avisa del fallo. */
  public checkRecord() {
    this.clearNotice();
    this.checkDoi();
    this.checkName();
    if (this.doiIcon === 'ion-md-create') {
      this.errorEnDoi = true;
    } else if (this.doiIcon === 'ion-md-close') {
      this.doiRepetido = true;
    } else if (this.nameIcon === 'ion-md-create') {
      this.errorEnNombre = true;
    } else if (this.genero === '' || this.genero === undefined) {
      this.errorEnGenero = true;
    } else if (
      this.fecha_de_ingreso === '' ||
      this.fecha_de_ingreso === undefined
    ) {
      this.errorEnFecha = true;
    } else if (!this.errorEnAvatar) {
      this.member = new Member(
        this.idRecibido,
        this.doiGrabar,
        this.nombreGrabar,
        this.fecha_de_ingreso,
        this.genero,
        this.activo,
        this.avatarName
      );
      this.buildDataPack(); // Empaquetamos todo (datos y avatar) en un solo objeto.
      this.saveRecord(); // Para grabar el objeto.
    }
  }

  /* El método que empaqueta datos y avatar en un objeto FormData */
  private buildDataPack() {
    const matriz = [
      { User: JSON.stringify(this.member) },
      { Avatar: this.avatarFile }
    ];
    this.dataPack = this.packService.pack(matriz);
  }

  /* Creado el objeto FormData se le pasa al servicio que lo envia a la API. */
  private saveRecord() {
    this.connectService
      .saveRecord$(this.dataPack)
      .subscribe(this.saveSuccess.bind(this), this.catchError.bind(this));
  }

  /* Si el proceso de alta o edición ha finalizado correctamente. */
  private saveSuccess(result) {
    if (result === '0') {
      this.registroGrabado = true;
    } else if (result === '23000') {
      this.doiRepetido = true;
    } else if (result === '42S22') {
      this.errorDeProceso = true;
    }
    if (this.idRecibido === '0') {
      this.restoreMemberForm();
    } else {
      this.readCurrentData();
    }
  }

  /* Si hay errores en las llamadas a las API's */
  private catchError(err) {
    this.errorDeProceso = true;
    this.errorMessage = err.message;
  }

  /* Se borran las notificaciones que se hayan podido producir.
  Este método se desencadena cuando se pone el foco en algún campo,
  o se pulsa el botón de envío o de reset. */
  public clearNotice() {
    this.errorEnAvatar = false;
    this.errorEnDoi = false;
    this.doiRepetido = false;
    this.errorEnNombre = false;
    this.errorEnFecha = false;
    this.errorEnGenero = false;
    this.errorDeProceso = false;
    this.registroGrabado = false;
  }

  /* Este método funciona para alta nueva y edición.
  Cuando se selecciona un avatar, lo asigna al fichero de avatar (para luego mandar a la API)
  y lo muestra en pantalla.
  Si se selecciona vacío, en alta nueva pone el avatar 'sin_avatar.jpg';
  en edición pone el avatar que hubiera.
  Si en edición se ha borrado el avatar que tenía, pone el avatar 'sin_avatar.jpg' */
  public selectAvatarToShow() {
    if ($('#AvatarFile')[0].files.length === 0) {
      if (this.idRecibido === '0') {
        this.imageToShow = this.connectService.URL + 'avatares/sin_avatar.jpg';
      } else {
        this.imageToShow = this.connectService.URL + this.member.avatar;
      }
      this.avatarFile = undefined;
    } else {
      this.avatarFile = $('#AvatarFile')[0].files[0];
      if (
        this.avatarFile['type'] !== 'image/jpeg' ||
        this.avatarFile['size'] > 40960
      ) {
        this.errorEnAvatar = true;
      } else {
        const reader: FileReader = new FileReader();
        reader.onloadend = () => {
          this.imageToShow = reader.result;
        };
        reader.readAsDataURL(this.avatarFile);
        this.errorEnAvatar = false;
      }
    }
  }

  /* Este método sólo es alcanzable desde edición,
  para poder borrar el avatar si se desea. */
  public borrarAvatar() {
    this.avatarName = 'avatares/sin_avatar.jpg';
    $('#AvatarFile')[0].value = null;
    this.imageToShow = this.connectService.URL + 'avatares/sin_avatar.jpg';
    this.avatarFile = undefined;
    this.clearNotice();
  }

  /* Cuando es un alta nueva se usa para poner como fecha de inscripción la del día. */
  private setCurrentDate() {
    this.fecha_de_ingreso = moment().format('YYYY-MM-DD');
  }

  /* El siguiente método es invocado por el botón de reset del formulario. */
  public restoreMemberForm() {
    if (this.idRecibido === '0') {
      this.doi = undefined;
      this.nombre = undefined;
      this.genero = undefined;
      this.setCurrentDate();
    } else {
      this.readCurrentData();
    }
    $('#AvatarFile')[0].value = null;
    this.selectAvatarToShow();
    this.clearNotice();
  }
}
